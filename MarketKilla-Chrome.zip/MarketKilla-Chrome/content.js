(function () {
  const TARGET_PATH =
    "/products";

  let currentUrl = location.href;
  let blockedCount = 0;
  let marketplaceHidden = true;
  let bannerElement = null;

  function isTargetPage() {
    try {
      const url = new URL(location.href);
      return url.pathname.startsWith(TARGET_PATH);
    } catch (e) {
      return false;
    }
  }

  function getExtensionTitle() {
    const manifest = chrome.runtime && chrome.runtime.getManifest
      ? chrome.runtime.getManifest()
      : null;
    return manifest && manifest.name
      ? manifest.name
      : "Bunnings Hide Marketplace Listings";
  }

  function ensureBanner() {
    if (bannerElement) return;

    const header = document.querySelector("header.sticky");
    if (!header || !header.parentElement) return;

    const banner = document.createElement("div");
    banner.id = "bhm-banner";

    // Basic styling (tweak as desired)
    banner.style.position = "relative";
    banner.style.zIndex = "9999";
    banner.style.backgroundColor = "rgb(188, 35, 24)";
    banner.style.color = "white";
    banner.style.padding = "8px 16px";
    banner.style.fontFamily = "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
    banner.style.display = "flex";
    banner.style.alignItems = "center";
    banner.style.justifyContent = "space-between";
    banner.style.fontSize = "1.2rem";

    const left = document.createElement("div");
    left.style.display = "flex";
    left.style.flexDirection = "column";

    const title = document.createElement("div");
    title.textContent = getExtensionTitle();

    const count = document.createElement("div");
    count.id = "bhm-count";
    count.style.fontSize = "1.1rem";
    count.style.opacity = "0.9";
    count.textContent = "Marketplace items found: " + blockedCount;

    left.appendChild(title);
    left.appendChild(count);

    const button = document.createElement("button");
    button.id = "bhm-toggle";
    button.textContent = "Show Marketplace Items";
    button.style.marginLeft = "16px";
    button.style.padding = "4px 10px";
    button.style.fontSize = "12px";
    button.style.borderRadius = "4px";
    button.style.border = "none";
    button.style.cursor = "pointer";
    button.style.backgroundColor = "#ffffff";
    button.style.color = "#004d40";

    button.addEventListener("click", () => {
      marketplaceHidden = !marketplaceHidden;
      updateTilesVisibility();
      updateBannerText();
    });

    banner.appendChild(left);
    banner.appendChild(button);

    header.parentElement.insertBefore(banner, header);

    bannerElement = banner;
  }

  function updateBannerText() {
    const countEl = document.getElementById("bhm-count");
    const toggleBtn = document.getElementById("bhm-toggle");
    if (countEl) {
      countEl.textContent = "Marketplace items blocked: " + blockedCount;
    }
    if (toggleBtn) {
      toggleBtn.textContent = marketplaceHidden
        ? "Show Marketplace Items"
        : "Hide Marketplace Items";
    }
  }

  function getMarketplaceArticles(root = document) {
    const articles = root.querySelectorAll(
      "article.search-product-tile.SearchResults-tile-analytics"
    );
    const result = [];

    articles.forEach((article) => {
      const badge = article.querySelector(".badgeText");
      const isMarketplace =
        badge &&
        typeof badge.textContent === "string" &&
        badge.textContent.trim().toLowerCase() === "marketplace";

      if (isMarketplace) {
        result.push(article);
      }
    });

    return result;
  }

  function hideMarketplaceTiles(root = document) {
    const marketplaceArticles = getMarketplaceArticles(root);

    marketplaceArticles.forEach((article) => {
      if (article.dataset.bhmProcessed === "1") return;
      if (marketplaceHidden) {
        article.style.display = "none";
      }
      article.dataset.bhmProcessed = "1";
      blockedCount++;
    });

    ensureBanner();
    updateBannerText();
  }

  function updateTilesVisibility() {
    const marketplaceArticles = getMarketplaceArticles();

    marketplaceArticles.forEach((article) => {
      if (marketplaceHidden) {
        article.style.display = "none";
      } else {
        article.style.display = "";
      }
    });
  }

  function enableDomObserver() {
    const observer = new MutationObserver((mutations) => {
      if (!isTargetPage()) return;

      for (const mutation of mutations) {
        if (mutation.type === "childList" && mutation.addedNodes.length > 0) {
          mutation.addedNodes.forEach((node) => {
            if (!(node instanceof HTMLElement)) return;

            if (
              node.matches &&
              node.matches("article.search-product-tile.SearchResults-tile-analytics")
            ) {
              hideMarketplaceTiles(node.parentNode || node);
            } else if (node.querySelectorAll) {
              const subArticles = node.querySelectorAll(
                "article.search-product-tile.SearchResults-tile-analytics"
              );
              if (subArticles.length > 0) {
                hideMarketplaceTiles(node);
              }
            }
          });
        }
      }
    });

    observer.observe(document.documentElement || document.body, {
      childList: true,
      subtree: true
    });
  }

  function resetStateForNewPage() {
    blockedCount = 0;
    marketplaceHidden = true;

    // Remove banner when navigating away or between “pages”
    if (bannerElement && bannerElement.parentElement) {
      bannerElement.parentElement.removeChild(bannerElement);
    }
    bannerElement = null;

    // Clear processed flags
    document
      .querySelectorAll("article.search-product-tile.SearchResults-tile-analytics")
      .forEach((a) => {
        delete a.dataset.bhmProcessed;
      });
  }

  function checkUrlAndRun() {
    const newUrl = location.href;
    if (newUrl === currentUrl) return;

    currentUrl = newUrl;

    resetStateForNewPage();

    if (isTargetPage()) {
      hideMarketplaceTiles();
    }
  }

  // Initial run on first load
  if (isTargetPage()) {
    hideMarketplaceTiles();
  }

  // Observe DOM for newly added products
  enableDomObserver();

  // Poll for SPA URL changes
  setInterval(checkUrlAndRun, 500);
})();
